# Collection of projects from ICS4UA course
